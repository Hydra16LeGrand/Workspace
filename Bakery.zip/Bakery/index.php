<!DOCTYPE html>
<html>
<head>
	<title>WELCOME</title>
	<meta charset="utf-8" name="viewport">
	<link rel="stylesheet" type="text/css" href="Public\CSS\bootstrap.min.css">
	<script type="text/javascript" src="Public\JS\bootstrap.min.js" ></script>
	<script type="text/javascript" src="Public\JS\jquery-slim.min.js" ></script>
	<script type="text/javascript" src="Public\JS\jquery.min.js" ></script>
</head>

<body>
	<div class="card">
		<div class="card-header" header style="background-image: url('Public/images/img13.jpg');">
			<div class="container " style="margin-top: 10px;box-shadow: -1px 1px 60px 15px #E8F6F3; background: rgba(0,0,0,0.4); " >
				<header>
					<div class="row" style="background-color: #E8F6F3;">
						<div class="container " >
							<a href="#" class="btn btn-link"> HOME </a>
							<a href="Views\create.php" class="btn btn-link">CREATE</a>
							<a href="Controllers\list.php" class="btn btn-link">PRODUCTS</a>
							<a href="Controllers\list_del.php" class="btn btn-link">DELETE</a>
							<a href="Controllers\list_update.php" class="btn btn-link">UPDATE</a>
						</div>
					</div> 
				</header>
			</div>
		</div>
		<div class="card-body">
			<blockquote class="blockquote mb-0">
				<p><center><h1><i>welcome in the</i> BARADJI's bakery </h1></center></p>
				<div>
					<div class="card-header border-warning mb-3">
							<center><b><i>Begin your day with our products</i></b></center>
					</div>
							<div class="card-body">
								<div class="container">
									<div class="row">
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Blueberry Donut</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Type : Donut</h5>
												<img height="170px" width="250px" src="Public/images/img (1).jpg">
											</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Bread Stuffed</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (1).gif">
										</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Strawberry Bread</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (13).jpg">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Chocolate Bread</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (4).gif">
											</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>French toats rolls up</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (6).gif">
										</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Classic Bread</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (5).gif">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Classic Red Bread</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (19).jpg">
											</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Chocolate croissant </i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Croissant</h5>
												<img height="170px" width="250px" src="Public/images/img (8).gif">
										</div>
										</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<div class="card border-warning mb-3 col-md-4" style="max-width: 20rem; max-height: 25rem;">
											<div class="card-header">
												<i>Classic Bread</i>
											</div>
											<div class="card-body text-primary">
												<h5 class="card-title">Bread</h5>
												<img height="170px" width="250px" src="Public/images/img (18).jpg">
											</div>
										</div>
									</div>
								</div>
							</div>
							
							
							
					</div>
					<div class="card-footer">
						<p><center><h3><i><b>the quality our priority ...</b></i></h3></center></p>
					</div>
				</div>
				<hr>
				<hr>
				<hr>
				<footer class="blockquote-footer" style="background-color: #77B5FE; color: black;"> 
					Copyright &copy; All right reserved <br>
					Date de creation du site <time>2019-05-02</time> by : <br>

					<address> 
						Baradji amara 
						Address Quartier Résidentiel<br>
						contact +225 56 74 85 29 
						Students of l'Université Polytechnique de Bingerville (UPB)<br>
						E-mail <a href="baradjiamara17@gmail.com" mailto:baradjiamara17@gmail.com>baradjiamara17@gmail.com</a>                                                                
					</address> 
				</footer>
			</blockquote>
		</div>		
	</div>
</body>
</html>
