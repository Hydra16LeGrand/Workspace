-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 18 nov. 2019 à 00:16
-- Version du serveur :  5.7.19
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `db_bakery`
--

-- --------------------------------------------------------

--
-- Structure de la table `products`
--
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `type`, `quantity`, `price`, `description`, `image`, `create_at`, `update_at`) VALUES
(1, 'Strawberry Bread', 'Bread', 50, 500, 'Slice of bread with strawberry jam isolates', 'img (13).jpg', '2019-11-17 22:41:37', '2019-11-17 22:41:37'),
(2, 'Croissant sausages', 'Croissant', 20, 1500, 'Croissant sausages style tacos', 'img (22).jpg', '2019-11-17 22:45:32', '2019-11-17 22:45:32'),
(3, 'French toats rolls up ', 'Bread', 60, 100, 'French toats rolls up  by chocolate', 'img (17).jpg', '2019-11-17 22:55:40', '2019-11-17 22:55:40'),
(4, 'Classic bread', 'Bread', 100, 300, 'Nothing is more classic than this one ', 'img (2).jpg', '2019-11-17 22:56:58', '2019-11-17 22:56:58'),
(5, 'Chocolate croissant', 'Croissant', 50, 300, 'Croissant with chocolate inside', 'img (29).jpg', '2019-11-17 22:59:09', '2019-11-17 22:59:09'),
(6, 'Multicolor croissant', 'Croissant', 20, 300, 'A multicolor croissant with different taste', 'img (25).jpg', '2019-11-17 23:01:20', '2019-11-17 23:01:20'),
(7, 'Multicolor shellfish croissant', 'Croissant', 30, 300, 'Multicolor croissant with shellfish form', 'img (37).jpg', '2019-11-17 23:03:31', '2019-11-17 23:03:31'),
(8, 'Classic croissant', 'Croissant', 30, 300, 'The savor of this croissant is very delicious since chandeliers ', 'img (21).jpg', '2019-11-17 23:07:03', '2019-11-17 23:07:03'),
(9, 'Cake chocolate', 'Cake', 10, 600, 'Cake with some chocolate tranchet', 'img (23).jpg', '2019-11-17 23:10:40', '2019-11-17 23:10:40'),
(10, 'Cake cook chocolate', 'Cake', 25, 350, 'This cake had been cooked with chocolate inside', 'img (5).jpg', '2019-11-17 23:12:14', '2019-11-17 23:12:14'),
(11, 'Birthday\'s cake 1', 'Cake', 5, 7000, 'For your birthday choose it you\'ll appreciate it', 'img (36).jpg', '2019-11-17 23:14:24', '2019-11-17 23:14:24'),
(12, 'Birthday\'s chocolate cake ', 'Cake', 3, 5000, 'Birthday\'s chocolate cake is better', 'img (35).jpg', '2019-11-17 23:17:02', '2019-11-17 23:17:02'),
(13, 'Little birthday cake', 'Cake', 4, 3000, 'The most little birthday\'s cake ', 'img (16).jpg', '2019-11-17 23:18:46', '2019-11-17 23:18:46'),
(14, 'Diversity of birthday\' cake', 'Cake', 15, 3500, 'Must cake for different savor', 'img (31).jpg', '2019-11-17 23:20:50', '2019-11-17 23:20:50'),
(15, 'Stick bread', 'Bread', 300, 150, 'Classic stick bread', 'img (27).jpg', '2019-11-17 23:24:04', '2019-11-17 23:24:04'),
(16, 'Harden bread', 'Bread', 15, 700, 'Harden bread during his conception', 'img (28).jpg', '2019-11-17 23:26:42', '2019-11-17 23:26:42'),
(17, 'Oiler chocolate bread  ', 'Bread', 50, 1000, 'A bread with oiler\'s chocolate', 'img (8).jpg', '2019-11-17 23:28:23', '2019-11-17 23:28:23'),
(18, 'Round bread', 'Bread', 120, 150, 'Classic round bread', 'img (30).jpg', '2019-11-17 23:29:52', '2019-11-17 23:29:52'),
(19, 'Biscuit bread heart', 'Bread', 60, 50, 'A biscuit bread with a heart form', 'img (34).jpg', '2019-11-17 23:32:23', '2019-11-17 23:32:23'),
(20, 'mixed croissant bread cake', 'Mixte', 5, 1500, 'A mixed product perfect for your breakfast', 'img (26).jpg', '2019-11-17 23:35:36', '2019-11-17 23:35:36');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
