<?php
session_start();
try{
	include('../Models/delete.php');

	$_SESSION['message'] = "The Product has been deleted !";
	$_SESSION['msg_type'] = "danger";
	header('Location: list_del.php');
}
catch(Exception $e){
		die('Error : '.$e -> getMessage());
	}
?>