<?php
	session_start();
	try{

		if (isset($_FILES['image']) AND $_FILES['image']['error'] == 0) {
			//Teste de la taille du fichier
			if ($_FILES['image']['size'] <= 7000000) {

				//Test de l'extension du fichier
				$infosFichier = pathinfo($_FILES['image']['name']);
				$extension_upload = $infosFichier['extension'];
				$extension_autorisees = array ('jpg','png','jpeg','gif');

				if (in_array($extension_upload, $extension_autorisees)){
					//On peut valider le stockage definitif
					move_uploaded_file($_FILES['image']['tmp_name'],'../Public/images_uploads/'.basename($_FILES['image']['name']));
					include('../Models/create.php');
				$_SESSION['message'] = "The Product has been created !";
				$_SESSION['msg_type'] = "success";
				header('Location: list.php');

				}
				else{
					echo "Extension de fichier non permis";
				}
				
			}
			else{
				echo "Fichier Trop Volumineux pour etre stocker";
			}
			
		}
		else{
			echo "Fichier inexistant";
		}
	}
	catch(Exception $e){
		die('Error : '.$e -> getMessage());
	}


?>