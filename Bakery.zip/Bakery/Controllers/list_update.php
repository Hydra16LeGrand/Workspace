<?php
session_start();
if (isset($_SESSION['message'])) : ?>
	<div class="alert alert-<?=$_SESSION['msg_type'] ?>">
		<?php 
		echo $_SESSION['message'];
		unset($_SESSION['message']);
		?>

	</div>
<?php endif ?>
<div class="card">
		<div class="card-header" header style="background-image: url('Public/images/img13.jpg');">
			<div class="container " style="margin-top: 10px;box-shadow: -1px 1px 60px 15px #E8F6F3; background: rgba(0,0,0,0.4); " >
				<header>
					<div class="row" style="background-color: #E8F6F3;">
						<div class="container " >
							<a href="..\index.php" class="btn btn-link"> HOME </a>
							<a href="..\Views\create.php" class="btn btn-link">CREATE</a>
							<a href="list.php" class="btn btn-link">PRODUCTS</a>
							<a href="list_del.php" class="btn btn-link">DELETE</a>
							<a href="#.php" class="btn btn-link">UPDATE</a>
						</div>
					</div> 
				</header>
			</div>
		</div>
	</div>
<br>
<?php  

	try{
		include_once('../Models/list.php');
		
		foreach ($donnees as $key => $donnee) {
			$donnees[$key]['id'] = htmlspecialchars($donnee['id']);
			$donnees[$key]['name'] = htmlspecialchars($donnee['name']);
			$donnees[$key]['type'] = htmlspecialchars($donnee['type']);
			$donnees[$key]['quantity'] = htmlspecialchars($donnee['quantity']);
			$donnees[$key]['description'] = htmlspecialchars($donnee['description']);
			$donnees[$key]['price'] = htmlspecialchars($donnee['price']);

		}
		include('../Views/update.php');
	}
	catch(Exception $e){
		die('Error : '.$e -> getMessage());
	}
	?>