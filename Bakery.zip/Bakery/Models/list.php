<?php
	include ("connection_sql.php");

	$donnees = $bdd -> prepare('SELECT * FROM products');
	$donnees -> execute();
	$donnees -> setFetchMode(PDO::FETCH_BOTH);
	$donnees = $donnees -> fetchAll();
	
?>