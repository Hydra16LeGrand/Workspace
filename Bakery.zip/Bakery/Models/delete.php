<?php

include('connection_sql.php');
$donnees = $bdd -> prepare('DELETE FROM products WHERE id=:id');
$donnees -> execute(array('id' => $_GET['id']));

?>