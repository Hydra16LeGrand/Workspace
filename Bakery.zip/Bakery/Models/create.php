<?php

	include('connection_sql.php');
	$donnees = $bdd -> prepare('INSERT INTO products (name,type,quantity,price,description, image) VALUES(:name,:type,:quantity,:price,:description,:image)');
	$donnees -> execute(array(
		'name' => $_POST['name'],
		'type' => $_POST['type'], 
		'quantity' => $_POST['quantity'], 
		'price' => $_POST['price'], 
		'description' =>$_POST['description'],
		'image' =>$_FILES['image']['name']
	));

?>