<?php

try{

	include('connection_sql.php');
	$donnees=$bdd -> prepare('UPDATE products SET name=:name,type=:type,quantity=:quantity,price=:price,description=:description,image=:image,update_at=NOW() WHERE id=:id');
	$donnees -> execute(array(
		'name' => $_POST['name'],
		'type' => $_POST['type'],
		'quantity' =>$_POST['quantity'],
		'price' => $_POST['price'],
		'description' => $_POST['description'],
		'image' => $_FILES['image']['name'],
		'id' => $_POST['id']
	));
}

catch(Exception $e){
	die("Error : ".$e -> getMessage());
}
?>