
<!DOCTYPE html>
<html>
<head>
	<title>The PRODUCTS</title>
	<meta charset="utf-8" name="viewport">
	<link rel="stylesheet" type="text/css" href="..\Public\CSS\bootstrap.min.css">
	<script type="text/javascript" src="..\Public\JS\bootstrap.min.js"></script>
	<script type="text/javascript" src="..\Public\JS\jquery.min.js"></script>
	<script type="text/javascript" src="..\Public\JS\jquery-slim.min.js"></script>

</head>
<body>
	

		<div class="container">
			
		
		<table class="table table-bordered table-striped table-hover">
			<legend><b>LIST OF PRODUCTS</b></legend>
			<tr><th>Id</th><th><center>Name</center></th><th><center>Type</center></th><th><center>Quantity</center></th><th><center>Price</center></th><th><center>Description</center></th><th><center>Image</center></th><th><center>ACTION</center></th></tr>
			<?php 

				foreach ($donnees as $donnee) { 
			?>
			<tr>
				<td><?php echo "<center>".$donnee['id']."<center>"; ?></td>
				<td><?php echo "<center>".$donnee['name']."<center>"; ?></td>
				<td><?php echo "<center>".$donnee['type']."<center>"; ?></td>
				<td><?php echo "<center>".$donnee['quantity']."<center>"; ?></td>
				<td><?php echo "<center>".$donnee['price']."<center>"; ?></td>
				<td><?php echo "<center>".$donnee['description']."<center>"; ?></td>
				<td><img width="300px" height="120px" src="<?php echo '../Public/images_uploads/'.$donnee['image']; ?>" ></td>
				<td>
					<center>
						<a class="btn btn-danger" href="..\Controllers\delete.php?id=<?php echo $donnee['id']; ?>">DELETE</a>
					</center>
				</td>

			</tr>
			<?php } 
			?>
		</table>
		</div>
	<hr>
	<hr>
	<hr>
<blockquote class="blockquote mb-0">
		<footer class="blockquote-footer" style="font-size: 15px; color: black; background-color: #9cd8ff;"> 
			Copyright &copy; All right reserved <br>
			Date de creation du site <time>2019-11-17</time> by : <br>

			<address> 
				Baradji amara 
				Address Quartier Résidentiel<br>
				contact +225 56 74 85 29 
				Students of l'Université Polytechnique de Bingerville (UPB)<br>
				E-mail <a href="baradjiamara17@gmail.com" mailto:baradjiamara17@gmail.com>baradjiamara17@gmail.com</a>                                                                
			</address> 
		</footer>
	</blockquote>

</body>
</html>