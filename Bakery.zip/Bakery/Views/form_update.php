<!DOCTYPE html>
<html>
<head>
	<title>Create a product</title>
	<meta charset="utf-8" name="viewport">
	<link rel="stylesheet" type="text/css" href="..\Public\CSS\bootstrap.min.css">
	<script type="text/javascript" src="..\Public\JS\bootstrap.min.js"></script>
	<script type="text/javascript" src="..\Public\JS\jquery.min.js"></script>
	<script type="text/javascript" src="..\Public\JS\jquery-slim.min.js"></script>
</head>
<body>
	<div class="card">
		<div class="card-header" header style="background-image: url('Public/images/img13.jpg');">
			<div class="container " style="margin-top: 10px;box-shadow: -1px 1px 60px 15px #E8F6F3; background: rgba(0,0,0,0.4); " >
				<header>
					<div class="row" style="background-color: #E8F6F3;">
						<div class="container " >
							<a href="..\index.php" class="btn btn-link"> HOME </a>
							<a href="create.php" class="btn btn-link">CREATE</a>
							<a href="..\Controllers\list.php" class="btn btn-link">PRODUCTS</a>
							<a href="..\Controllers\list_del.php" class="btn btn-link">DELETE</a>
							<a href="..\Controllers\list_update.php" class="btn btn-link">UPDATE</a>
						</div>
					</div> 
				</header>
			</div>
		</div>
	</div>
	<br>
	
	<div class="container">
		<form method="POST" action="..\Controllers\update.php" enctype="multipart/form-data">
			<div class="row justify-content-center" >
				<div class="form-group">
					
					<p><label for="id"></label><b>ID</b><br/><input type="number" name="id" id="id"  required value="<?php echo $_GET['id']; ?>" class="form-control"></p>
					<p><label for="name"></label><b>NAME</b><br/><input type="text" name="name" id="name"  required value="<?php echo $_GET['name']; ?>" class="form-control"></p>
				
					<p><label for="type"></label><b>TYPE</b><br/><input type="text" name="type" id="type" class="form-control" required value="<?php echo $_GET['type']; ?>"></p>

					<p><label for="quantity"></label><b>QUANTITY</b><br/><input type="number" name="quantity" id="quantity" class="form-control" required value="<?php echo $_GET['quantity']; ?>"></p>

					<p><label for="price"></label><b>PRICE</b><br><input type="number" name="price" id="price" class="form-control" required value="<?php echo $_GET['price']; ?>"></p>

					<p><label for="description"></label><b>DESCRIPTION</b><br><input type="textarea" name="description" id="description" class="form-control" required value="<?php echo $_GET['description']; ?>"></p>

					<p><b>IMAGE</b><br><input type="file" name="image" required value="<?php echo $_GET['image']; ?>"> </p>

				<input type="submit" value="update" class="btn btn-success">
				</div>
			</div>
		</form>
	</div>
	<hr>
	<hr>
	<hr>
<blockquote class="blockquote mb-0">
		<footer class="blockquote-footer" style="font-size: 15px; color: black; background-color: #9cd8ff;"> 
			Copyright &copy; All right reserved <br>
			Date de creation du site <time>2019-11-17</time> by : <br>

			<address> 
				Baradji amara 
				Address Quartier Résidentiel<br>
				contact +225 56 74 85 29 
				Students of l'Université Polytechnique de Bingerville (UPB)<br>
				E-mail <a href="baradjiamara17@gmail.com" mailto:baradjiamara17@gmail.com>baradjiamara17@gmail.com</a>                                                                
			</address> 
		</footer>
	</blockquote>
</body>
</html>