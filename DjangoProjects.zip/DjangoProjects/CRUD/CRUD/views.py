from django.shortcuts import render

def handler404(request):
	return render(request,"errors/handler404.html",{},status=404)