from django.db import models
from django import forms

# Create your models here.


class Temps_actu(models.Model):
	creer_le = models.DateTimeField(auto_now_add=True)
	modifier_le = models.DateTimeField(auto_now=True)

	class Meta:
		abstract = True


class Person(Temps_actu):

	nom = models.CharField(max_length=100)
	prenom = models.CharField(max_length=100)
	metier = models.CharField(max_length=100)
	

	def __str__(self):
		return self.nom


class Enr(forms.Form):
	nom = forms.CharField(label="Votre nom")
	prenom = forms.CharField(label="Votre prenom")
	age = forms.IntegerField()