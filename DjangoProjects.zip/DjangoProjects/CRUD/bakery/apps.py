from django.apps import AppConfig


class BakeryConfig(AppConfig):
    name = 'bakery'
