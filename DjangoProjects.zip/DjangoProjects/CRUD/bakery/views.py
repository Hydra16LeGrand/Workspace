from django.shortcuts import render
from django.http import HttpResponse
from . import mocks

from . import models
# Create your views here.

def index(request):
	articles = mocks.Article.all()
	return render(request,"index.html",{'articles':articles})

def read(request,id):
	
	return render(request,"read.html",{'article':mocks.Article.article(id)})

def enregistrement(request):
	enr = models.Enr()

	return render(request,"enregistrement.html",{'enr':enr})