from django.http import Http404
class Article:
	articles=[
		{'id':1,'libel':"article1",'contenu':"mon 1er artcile"},
		{'id':2,'libel':"article2",'contenu':"mon 2nd artcile"},
		{'id':3,'libel':"article3",'contenu':"mon 3eme artcile"},
	]

	@classmethod
	def all(cls):
		return cls.articles

	@classmethod
	def article(cls, id):
		try:
			return cls.articles[int(id)-1]
		except :
			raise Http404("Desole la page avec l'id : {} n'existe pas !".format(id))
		
		
		
