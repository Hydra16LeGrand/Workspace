from django.apps import AppConfig


class GestionnaireConfig(AppConfig):
    name = 'gestionnaire'
