from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Niveau(models.Model):

	niveau = models.IntegerField()

	def __str__(self):

		return "Niveau ",self.niveau


class Groupe(models.Model):

	groupe = models.CharField(max_length = 8)
	

class Classe(models.Model):

	niveau = models.ForeignKey(Niveau, on_delete = models.CASCADE)
	groupe = models.ForeignKey(Groupe, on_delete = models.CASCADE)
	classe = models.CharField(max_length=100)
	description = models.CharField(max_length=100)
	

class Matiere(models.Model):

	matiere = models.CharField(max_length = 20)
	groupe = models.ForeignKey(Groupe, on_delete = models.CASCADE)

	

class Eleve(models.Model):

	nom_eleve = models.CharField(max_length=100)
	prenom_eleve = models.CharField(max_length=100)
	num_tel_eleve = models.CharField(max_length=100, blank=True)
	adresse_eleve = models.CharField(max_length=255)
	date_naissance_eleve = models.DateField(blank=True)
	nationalite_eleve = models.CharField(max_length=100)

	date_ajout = models.DateTimeField(auto_now_add = True)
	date_modification = models.DateTimeField(auto_now =True)

	classe = models.ManyToManyField(Classe, related_name='eleve')

	image = models.ImageField(upload_to="profils_eleves/", blank=True)
	matricule = models.CharField(max_length=100, blank=True)
	status_scolarite = models.BooleanField(blank=True)
	reste_a_payer = models.IntegerField(blank=True, default=0)


class Parent(models.Model):


	nom_parent = models.CharField(max_length = 100)
	prenom_parent = models.CharField(max_length = 100)
	adresse_parent = models.CharField(max_length = 255)
	num_tel_parent = models.CharField(max_length=100, blank = True)
	email_parent = models.EmailField(blank = True)
	profession = models.CharField(max_length=100)
	nationalite_parent = models.CharField(max_length=100)

	lien_de_parente = models.CharField(max_length = 100)

	date_ajout = models.DateTimeField(auto_now_add = True)
	date_modification = models.DateTimeField(auto_now=True)

	eleve = models.ForeignKey(Eleve, on_delete = models.CASCADE)

	utilisateur = models.OneToOneField(User, on_delete=models.CASCADE, blank=True)
	antecedant_judiciaire = models.TextField(blank=True)
	image = models.ImageField(upload_to="profils_parents/", blank=True)
	situation_financiere = models.CharField(max_length=100, blank=True)
	

class Enseignant(models.Model):
	
	nom_enseignant = models.CharField(max_length = 100)
	prenom_enseignant = models.CharField(max_length = 100)
	adresse_enseignant = models.CharField(max_length = 255)
	num_tel_enseignant = models.CharField(max_length=100, blank = True)
	date_naissance_enseignant = models.DateField(blank = True)
	email_enseignant = models.EmailField(blank = True)
	autre_profession = models.CharField(max_length=100, blank=True)
	nationalite_enseignant = models.CharField(max_length=100)

	date_ajout = models.DateTimeField(auto_now_add = True)
	date_modification = models.DateTimeField(auto_now=True)

	groupe = models.ManyToManyField(Groupe, related_name = 'enseignant')

	image = models.ImageField(upload_to="profils_enseignants/", blank=True)
	antecedant_judiciaire = models.TextField(blank=True)
	ancienne_profession = models.CharField(max_length=100, blank=True)
	salaire = models.IntegerField(blank=True)
	periode = models.CharField(max_length=100, blank=True)
	regularite = models.BooleanField(blank=True)

	utilisateur = models.OneToOneField(User, on_delete=models.CASCADE, blank=True)



class Commentaire(models.Model):

	destinataire = models.BooleanField(blank=True)
	id_destinataire = models.IntegerField(blank=True)
	commentateur = models.BooleanField(blank=True)
	commentaire = models.TextField(blank=True)


class Note(models.Model):

	note = models.IntegerField(blank=True)
	remarque = models.CharField(max_length=255, blank=True)

	eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE)
	enseignant = models.ForeignKey(Enseignant, on_delete=models.CASCADE)
	matiere = models.ForeignKey(Matiere, on_delete=models.CASCADE)

class Moyenne(models.Model):

	moyenne = models.IntegerField(blank=True)
	remarque = models.CharField(max_length=255, blank=True)

	eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE)
	enseignant = models.ForeignKey(Enseignant, on_delete=models.CASCADE)
	matiere = models.OneToOneField(Matiere, on_delete=models.CASCADE)


class MoyenneGenerale(models.Model):

	moyenne_generale = models.IntegerField(blank=True)
	remarque = models.CharField(max_length=255, blank=True)
	decision = models.CharField(max_length=100, blank=True)

	eleve = models.OneToOneField(Eleve, on_delete=models.CASCADE)
	enseignant_principal = models.ForeignKey(Enseignant, on_delete=models.CASCADE)