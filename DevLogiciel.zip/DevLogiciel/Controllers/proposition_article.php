<?php 
//vérification de l'existence du cookie
if (isset($_COOKIE['mavar'])) {
	// Session qui va permettre d'afficher un message d'alerte lorsqu'un article est proposé.
	session_start();
	echo "<br>";
	#Inclusion du fichier qui va permettre l'insertion des donnees de l'article proposé dans la base de donnée.
	require('../Models/proposition_article.php');
	$_SESSION['message']="<center>La proposition de l'article à bien été enregistrée</center>";
	$_SESSION['msg_type']="success";
	// Rédirection vers la liste des articles proposés
	header('Location: list_article_proposes.php');
}
else{
	header('Location:../index.php');
}


?>