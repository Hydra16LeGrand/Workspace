<?php

//vérification de l'existence du cookie
if (isset($_COOKIE['mavar'])) {
	// Session qui va permettre d'afficher un message d'alerte lorsqu'un article est évalué.
	session_start();
	$_SESSION['message_eval']="<center>L'article à été évalué avec succès</center>";
	$_SESSION['msg_type']="success";

	echo "<br>";
	// Inclusions de l'entête
	require('../Statics/header.php');
	#Inclusion du fichier qui va permettre l'insertion des donnees de l'article ajouté dans la base de donnée.
	require('../Models/evaluation_article.php');
	#Inclusion du fichier qui va permettre la réccuperation  des informations sur les article ajoutés. Cette page sera afficher de nouveau après qu'un article ai été evalué.
	require('../Models/list_article_ajoutes.php');
	// Inclusions du fichier comportant la partie visible par l'utilisateur qui contient le code html de la liste des articles ajoutés.
	require('../Views/list_article_ajoutes.php');

}
else{
	header('Location:../index.php');
}

?>