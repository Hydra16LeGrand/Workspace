<?php 
//vérification de l'existence du cookie
if (isset($_COOKIE['mavar'])) {

	// Inclusions de l'entête
	require('../Statics/header.php');

	#Inclusion du fichier qui va permettre la réccuperation  des informations sur les article évalués.
	require('../Models/list_article_evalues.php');

	// Inclusions du fichier comportant la partie visible par l'utilisateur qui contient le code html de la liste des articles évalués.
	require('../Views/list_article_evalues.php');
}
else{
	header('Location:../index.php');
}


?>