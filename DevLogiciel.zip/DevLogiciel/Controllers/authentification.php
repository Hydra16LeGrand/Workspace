<?php 

require('../Models/authentification.php');
$mavar = false;
if (isset($_POST['connexion'])) {
	

	while ($reponse = $donnees->fetch()) {
		if ($reponse['id_utilisateur'] == $_POST['id_utilisateur'] AND $reponse['mdp_utilisateur'] == $_POST['mdp_utilisateur']) {
			$mavar = true;
			setcookie("mavar",$mavar,time()+3600);
		}
	}

	$donnees->closeCursor();
	if ($mavar) {
		header('Location:../accueil.php');
	}else{
		?>
			<h1> Mot de pass incorrect </h1>
		<?php
		header('Location:../index.php');
	}
}
?>