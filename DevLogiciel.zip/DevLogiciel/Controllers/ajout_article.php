<?php 
// Vérification de l'existence du cookie de connexion.
if (isset($_COOKIE["mavar"])) {
	// Session qui va permettre d'afficher un message d'alerte lorsqu'un article est ajouté.
	session_start();
	#Inclusion du fichier qui va permettre l'insertion des donnees de l'article proposé dans la base de donnée.
	require('../Models/ajout_article.php');

	$_SESSION['message']= "L'article à bien été ajouté";
	$_SESSION['msg_type']="success";
	// Rédirection vers la liste des articles ajoutés.
	header('Location: list_article_ajoutes.php');
}
else{
	header('Location:../index.php');
}

?>