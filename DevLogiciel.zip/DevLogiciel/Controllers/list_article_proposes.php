<?php 
//vérification de l'existence du cookie
if (isset($_COOKIE['mavar'])) {
	// Récupération des données de session dépuis le fichier proposition_article.php
	session_start();
	if (isset($_SESSION['message'])) {?>
		<div class="alert alert-<?= $_SESSION['msg_type']; ?>">
	<?php 
	echo $_SESSION['message'];
	unset($_SESSION['message']);
	// Destruction de la session
	session_destroy();
	?>

		</div>
	<?php	
	}
	echo "<br>";
	// Inclusions de l'entête
	require('../Statics/header.php');

	#Inclusion du fichier qui va permettre la réccuperation  des informations sur les article proposés.
	require('../Models/list_article_proposes.php');

	// Inclusions du fichier comportant la partie visible par l'utilisateur qui contient le code html de la liste des articles proposés
	require('../Views/list_article_proposes.php');

}
else{
	header('Location:../index.php');
}

?>