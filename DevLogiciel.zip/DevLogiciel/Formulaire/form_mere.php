<?php

// Cette classe servira de classe mère de la classe Form_evaluation_article du fichier Form_evaluation_article.php
class FormMere{

// Création d'un formulaire dynamique
	protected $formHtml;

	public function __construct($action,$method,$legend){
		$this->formHtml='<br><div class="container" style="background-color: white;"><form method='.$method.' action='.$action.'><fieldset class="form-group"><legend class="col-md-12 col-form-label pt-0">'.$legend.'</legend><div style="background-size: 200px;">';
	}

	public function setText($type,$label,$name,$placeholder){
		$this->formHtml.="<div class='row'><label class='col-sm-2 col-form-label' for=$label></label><input class='form-control' type=$type name=$name id=$label required placeholder="."'".$placeholder."'"."></div>";

	}

	public function setTextArea($label,$name,$placeholder){
		$this->formHtml.="<div class='row'><label class='col-sm-2 col-form-label' for=$label></label><textarea class='form-control' name=$name id=$label required placeholder="."'".$placeholder."'"."></textarea></div><br>";

	}
	public function setSubmit($value){
		$this->formHtml.="<center><input class='btn-outline-primary my-2 my-sm-0' type='submit' value=$value ></center>";
	}
	
	public function getForm(){

		$this->formHtml.="</div></fieldset></form></div>";
		return $this->formHtml;
	}	
}

?>