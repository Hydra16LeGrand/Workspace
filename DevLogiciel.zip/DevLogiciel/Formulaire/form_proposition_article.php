
<?php
echo "<br>";
// inclusion de l'entete contenant le menu
require('../Statics/header.php');


include("../Statics/lien_css.php"); 

// Inclusion du fichier contenant la classe FormMere
require('form_mere.php');

// Création d'instance de la classe FormMere et rédirection des données qui seront saisies vers le fichier proposition_article.php du dossier controllers après remplissage.
$new_form = new FormMere('../Controllers/proposition_article.php','POST',"<legend><i>Formulaire de proposition</i></legend>");
$new_form->setText('textarea','titre','titre',"titre article");
$new_form->setTextArea('noms_prenoms_auteurs','noms_prenoms_auteurs','Les noms et prénoms des évaluateurs séparés par des virgules');
$new_form->setTextArea('resume','resume','Le résumé');
$new_form->setSubmit('soumettre');

?>
<center>
	<div class="card" style="width: 30rem;">
	  	<div class="card-body">
	    	<?php echo $new_form->getForm(); ?>
		</div>
	</div>
</center>
<?php

include('../Statics/footer.php');

?>