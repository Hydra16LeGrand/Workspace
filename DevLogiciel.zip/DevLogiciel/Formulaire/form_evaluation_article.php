
<?php

// inclusion de l'entete contenant le menu
echo "<br>";
require('../Statics/header.php');

// inclusion du formulaire parent
require('form_mere.php');

// inclusion des lien pour le design (bootstrap)
include("../Statics/lien_css.php"); 

class FormEvaluationArticle extends FormMere{
	public function __construct($action,$method,$legend){
		parent:: __construct($action,$method,$legend);
	}

	public function setSelect($label, $name){
		$this->formHtml .= "<br>Note<br><div class='row'> <select class='form-control' name=$name ><option value=1>1</option><option value=2>2</option><option value=3>3</option><option value=4>4</option></select></div>";
	}
	public function setTextPreRemplie($type,$label,$name,$default){
		$this->formHtml.="<div class='row'><br><label class='col-sm-2 col-form-label' for=$label></label><input class='form-control' type=$type name=$name id=$label value=$default required placeholder=$label></div><br>";
	}

}

// création d'instance
$new_form = new FormEvaluationArticle("../Controllers/evaluation_article.php",'POST',"<legend><i>Fourmulaire d'évaluation</i></legend>");

$new_form->setTextPreRemplie('text','titre','titre',$_GET['titre']);
$new_form->setText('text','nom_evaluateur','nom_evaluateur','Nom évaluateur');

$new_form->setSelect('Note','note_evaluation');
$new_form->setTextArea('mess_president','mess_president','Le méssage au président');
$new_form->setTextArea('commentaire','commentaire','Un commentaire');
$new_form->setTextPreRemplie('number','id_article','id_article',$_GET['id_article']);

$new_form->setSubmit('soumettre');
?>
<center>
	<div class="card" style="width: 35rem;">
	  <div class="card-body">
	    <?php echo $new_form->getForm(); ?>
	  </div>
	</div>
</center>
<?php

include('../Statics/footer.php');
?>