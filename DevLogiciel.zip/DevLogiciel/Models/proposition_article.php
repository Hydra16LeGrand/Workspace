<?php

#inclusion du fichier de connexion à la base de donnée pour utilisation.
require('connexion_bd.php');

#Un bloc try catch pour ne pas afficher des informations sur la base de donnée en cas d'erreur.
try{
	#Réquête sql permettant d'insérer les données du formulaire de proposition dans la base  de donnée.
	$donnees = $bdd -> prepare("
		INSERT INTO Article (titre,noms_prenoms_auteurs,resume,statu) 
		VALUES (:titre,:noms_prenoms_auteurs,:resume,0)
		;");
	#Exécution de la réquête.
	$donnees -> execute(array(
		'titre' => $_POST['titre'],
		'noms_prenoms_auteurs' => $_POST['noms_prenoms_auteurs'],
		'resume' => $_POST['resume']
	));
}
catch(Exception $e) {
		die('Erreur avec la requette d\'insertion : '.$e->getMessage());
}

?>