<?php
#Fichier de connexion à la base de donnée DevLogiciel
	#Un bloc try catch pour ne pas afficher des informations sur la base de donnée en cas d'erreur.
	try{
		$bdd = new PDO('mysql:host=localhost;dbname=DevLogiciel','root','root',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
	}
	catch(Exception $e){
		die('Connexion à la base de donnée : '.$e->getMessage());
	}
?>