<?php
#inclusion du fichier de connexion à la base de donnée pour utilisation.
require('connexion_bd.php');

#Un bloc try catch pour ne pas afficher des informations sur la base de donnée en cas d'erreur.
try{
	#Réquête sql permettant de réccuperer les articles proposés de la table Article.
	/* Ici le 0 signifie que les articles sélectionnés sont des arcticles proposés;
		Le 1, les articles ajoutés et le 2, les articles évalués */

	$donnees = $bdd -> prepare('SELECT * from Article WHERE statu=2');
	#Exécution de la réquête.
	$donnees -> execute();
}
catch(Exception $e) {
		die('Erreur avec la requette de recuperation : '.$e->getMessage());
}

?>