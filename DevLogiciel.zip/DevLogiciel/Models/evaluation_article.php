<?php

#inclusion du fichier de connexion à la base de donnée pour utilisation.
require('connexion_bd.php');

#Un bloc try catch pour ne pas afficher des informations sur la base de donnée en cas d'erreur.
try{
	#Réquête sql permettant d'insérer les données du formulaire de proposition dans la base  de donnée.
	$donnees_temp = $bdd -> prepare("
		INSERT INTO Evaluation (nom_evaluateur,note_evaluation,mess_president,commentaire,id_article,titre) 
		VALUES (:nom_evaluateur,:note_evaluation,:mess_president,:commentaire,:id_article,:titre)
		;");
	#Exécution de la réquête.
	$donnees_temp -> execute(array(
		'nom_evaluateur' => $_POST['nom_evaluateur'],
		'note_evaluation' => $_POST['note_evaluation'],
		'mess_president' => $_POST['mess_president'],
		'commentaire' => $_POST['commentaire'],
		'id_article' => $_POST['id_article'],
		'titre' => $_POST['titre']
	));

	if (isset($_SESSION['message_eval'])) {?>
	<div class="alert alert-<?=$_SESSION['msg_type'] ?>">
	<?php 
		echo $_SESSION['message_eval'];
		unset($_SESSION['message_eval']);
		session_destroy();
	}?>
		</div>
	<?php
	$id_article = $_POST['id_article']; 

	// le reste du code porte sur le fait que un article doit être évalué trois fois
	// Ainsi d'abord nous reccupérons le nombre d'évaluation dépuis la base de donnée
	$donnees = $bdd ->prepare('SELECT nombre_evaluation FROM Article WHERE id_article=:id_article');
	$donnees -> execute(array('id_article' => $id_article ));

	// Une boucle permettant de réccuperer le nombre d'évaluation dépuis un tableau vers une variable 
	foreach ($donnees as $donnee) {
		$nombre_evaluation = $donnee['nombre_evaluation'];
	}

	// Vérification si le nombre d'évaluation vaut 2 , si c'est le cas on change le statu à 2 qui signifie que l'article à été évaluer 3 fois
	if ($nombre_evaluation == 2) {
		$donnees = $bdd -> prepare('UPDATE Article set statu=2 WHERE id_article=:id_article');
		$donnees -> execute(array('id_article' => $id_article ));
	}
	// Sinon on incrémente le nombre d'évaluation et on l'insère dans la base de donnée
	else{
		$nombre_evaluation += 1;
		$donnees = $bdd -> prepare('UPDATE Article set nombre_evaluation=:nombre_evaluation WHERE id_article=:id_article');
		$donnees -> execute(array(
			'nombre_evaluation' => $nombre_evaluation,
			'id_article' => $id_article ));
		
	}
}
catch(Exception $e) {
		die('Erreur avec la requette d\'insertion : '.$e->getMessage());
}

?>