<!-- Ce fichier sert à l'affichage des articles proposés -->
<!DOCTYPE html>
<html>
<head>
	<title>Liste des articles proposés</title>
	<?php include("../Statics/lien_css.php"); ?>
</head>
<body>
	<br>
<div class="container">
	<div class="row">
		<h1>
			<p class="display-5"><ins>LISTE DES ARTICLES PROPOSES</ins></p>
		</h1>
	</div>
	<div class="row table-responsive">
		<table class="table table-bordered table-striped table-hover table-sm">
			<tr><th>Numéro Article</th><th><center>titre</center></th><th><center>noms et prenoms des auteurs</center></th><th><center>resume</center></th><th colspan="2"><center>Action</center></th></tr><br>
			<?php foreach ($donnees as $donnee) { 
				$noms_prenoms_auteurs = explode(',', $donnee['noms_prenoms_auteurs']);
				$donnee['noms_prenoms_auteurs']="";
				foreach ($noms_prenoms_auteurs as $key) {
					$donnee['noms_prenoms_auteurs'] .= "<br>".$key;
				}

				?>
			<tr>
				<td><center><?php echo $donnee['id_article'];?></center></td>
				<td><center><?php echo $donnee['titre']; ?></center></td>
				<td><center><?php echo $donnee['noms_prenoms_auteurs']; ?></center></td>
				<td><center><?php echo $donnee['resume']; ?></center></td>
				<td><center><a class="btn btn-outline-success" href="../PdfArticle/pdf_article_proposes.php?id_article=<?php echo $donnee['id_article']; ?>">pdf</a></center></td>
				<td><center><a class="btn btn-primary" href="../Controllers/ajout_article.php?id_article=<?php echo $donnee['id_article']; ?>">Ajouter</a></center></td><br>
			</tr>
			<?php }?>
		</table>
	</div>
	
</div>
<?php include('../Statics/footer.php'); ?>
</body>
</html>