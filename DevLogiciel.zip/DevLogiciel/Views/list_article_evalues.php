<!-- Ce fichier sert à l'affichage des articles évalués -->
<!DOCTYPE html>
<html>
<head>
	<title>Liste des articles évalués</title>
	<?php include("../Statics/lien_css.php"); ?>
</head>
<body>
	<br>

	<div class="container">
		<div class="row">
			<h1>
				<p class="display-5"><ins>LISTE DES ARTICLES EVALUES</ins></p>
			</h1>
		</div>
		<div class="row table-responsive">
			<table class="table table-bordered table-striped table-hover table-sm">
				<tr><th><center>Numéro <br>Article</center></th><th><center>titre</center></th><th><center>noms et prenoms <br>des auteurs</center></th><th><center>resumé</center></th></tr>
				<?php foreach ($donnees as $donnee) { 
					$resume1=substr($donnee['resume'], 0,60);
					$resume2=substr($donnee['resume'], 61,120);
					$resume3=substr($donnee['resume'], 121,180);
					$resume=$resume1."\n".$resume2."\n".$resume3;
					?>
				<tr>
					<td><center><?php echo $donnee['id_article']; ?></center></td>
					<td><center><?php echo $donnee['titre']; ?></center></td>
					<td><center><?php echo $donnee['noms_prenoms_auteurs']; ?></center></td>
					<td><center><?php echo $resume; ?></center></td><br>
				</tr>
				<?php }?>
			</table>
		</div>
		
	</div>
	<?php include('../Statics/footer.php'); ?>
</body>
</html>
