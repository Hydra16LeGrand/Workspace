<!-- Ce fichier sert à l'affichage des articles ajoutés -->
<!DOCTYPE html>
<html>
<head>
	<title>Listes des articles ajoutés</title>
	<?php include("../Statics/lien_css.php"); ?>
</head>
<body>
	<br>
	<div class="container table-responsive">
		<div class="row">
			<h1>
				<p class="display-5"><ins>LISTE DES ARTICLES AJOUTES</ins></p>
			</h1>
		</div>
		<div class="row table-responsive">
			<table class="table table-bordered table-striped table-hover table-sm">
			<tr><th><center>Numéro<br>Article</center></th><th><center>Titre</center></th><th><center>Noms et prenoms <br>des auteurs</center></th><th><center>Resumé</center></th><th><center>Nombre<br>Evaluation</center></th><th><center>Action</center></th><br></tr>
			<?php foreach ($donnees as $donnee) { 
				$noms_prenoms_auteurs = explode(',', $donnee['noms_prenoms_auteurs']);
				$donnee['noms_prenoms_auteurs']="";
				foreach ($noms_prenoms_auteurs as $key) {
					$donnee['noms_prenoms_auteurs'] .= "<br>".$key;
				}

				?>
			<tr>
				<td><center><?php echo $donnee['id_article'];?></center></td>
				<td><center><?php echo $donnee['titre']; ?></center></td>
				<td><center><?php echo $donnee['noms_prenoms_auteurs']; ?></center></td>
				<td><center><?php echo $donnee['resume']; ?></center></td>
				<td><center><?php echo $donnee['nombre_evaluation']; ?>/3</center></td>
				<td><center><a class="btn btn-primary" href="../Formulaire/form_evaluation_article.php?titre=<?php echo $donnee['titre']; ?>&amp;id_article=<?php echo $donnee['id_article']; ?>">Évaluer</a></center></td><br>
			</tr>
			<?php }?>
		</table>
		</div>
		
	</div>
<?php include('../Statics/footer.php'); ?>
</body>
</html>