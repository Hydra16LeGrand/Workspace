<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V1</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="icon" type="image/png" href="Statics/images/icons/favicon.ico"/>

	<link rel="stylesheet" type="text/css" href="Statics/vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="Statics/fonts/font-awesome-4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="Statics/vendor/animate/animate.css">

	<link rel="stylesheet" type="text/css" href="Statics/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="Statics/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="Statics/css/util.css">
	<link rel="stylesheet" type="text/css" href="Statics/css/main.css">
</head>
<body>

		<div class="limiter">
			<div class="container-login100">
				<div class="wrap-login100">
					<div class="login100-pic js-tilt" data-tilt>
						<img src="Statics/images/img-01.png" alt="IMG">
					</div>

					<form class="login100-form validate-form" method="post" action="Controllers/authentification.php">
						<span class="login100-form-title">
							Authentification
						</span>

						<div class="wrap-input100 validate-input" data-validate = "Un identifiant valide est réquis">
							<input class="input100" type="text" name="id_utilisateur" placeholder="Identifiant">
							<span class="focus-input100"></span>
							<span class="symbol-input100">
								<i class="fa fa-envelope" aria-hidden="true"></i>
							</span>
						</div>

						<div class="wrap-input100 validate-input" data-validate = "Un mot de passe est réquis">
							<input class="input100" type="password" name="mdp_utilisateur" placeholder="mot de passe">
							<span class="focus-input100"></span>
							<span class="symbol-input100">
								<i class="fa fa-lock" aria-hidden="true"></i>
							</span>
						</div>
						
						<div class="container-login100-form-btn">
							<button class="login100-form-btn" name="connexion">
								connexion
							</button>
						</div>
						<div class="container-login100-form-btn">
							
							<a href="Formulaire/form_proposition_article.php" class="btn btn-link">Proposer Article</a>
						</div>

						<!-- <div class="text-center p-t-12">
							<span class="txt1">
								Forgot
							</span>
							<a class="txt2" href="#">
								Username / Password?
							</a>
						</div>

						<div class="text-center p-t-136">
							<a class="txt2" href="#">
								Create your Account
								<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
							</a>
						</div> -->
					</form>
				</div>
			</div>
		</div>
	

	<script src="Statics/vendor/jquery/jquery-3.2.1.min.js"></script>

	<script src="Statics/vendor/bootstrap/js/popper.js"></script>
	<script src="Statics/vendor/bootstrap/js/bootstrap.min.js"></script>

	<script src="Statics/vendor/select2/select2.min.js"></script>

	<script src="Statics/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>

	<script src="Statics/js/main.js"></script>

</body>
</html>