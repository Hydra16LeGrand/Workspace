<!-- La fichier qui affichera la page d'accueil -->
 

<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap-grid.min.css">
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap-reboot-min.css">
	<link rel="stylesheet" type="text/css" href="Statics/bootstrap-4.4.1-dist/css/bootstrap-reboot.css">
	<script type="text/javascript" src="Statics/bootstrap-4.1.1-dist/bootstrap.js"></script>
	<script type="text/javascript" src="Statics/bootstrap-4.1.1-dist/bootstrap.min.js"></script>
	<script type="text/javascript" src="Statics/bootstrap-4.1.1-dist/bootstrap.bundle.min.js"></script>
	<script type="text/javascript" src="Statics/bootstrap-4.1.1-dist/bootstrap.bundle.js"></script>
</head>
<body >
<?php require('Statics/header_index.php'); ?>

	<div class="container ">
		<h1><p class="display-5"><center><abbr title="GESTION DE SOUMISSION" style="color: #2c75ff;">BIENVENUE SUR LA PLATEFORME DE GESTION<br> DE SOUMISSION D'ARTICLES SCIENTIFIQUES</abbr></center></p></h1>
	</div>
	
	<?php 
 echo "<br>";
 
?> 
<?php include('Statics/footer_index.php'); ?>
</body>
</html>