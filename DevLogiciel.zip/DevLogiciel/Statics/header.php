<!-- Entete des autres fichiers excepté index.php qui est à la racine -->
<div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>

</div>
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" href="../accueil.php">Accueil</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../Formulaire/form_proposition_article.php">Proposer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../Controllers/list_article_proposes.php">Ajouter</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../Controllers/list_article_ajoutes.php">Evaluer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../Controllers/list_article_evalues.php">Articles Evalués</a>
      </li>
    </ul>
  </div>
  <div class="card-body">
    <h1 class="card-title display-1" style="color: #2c75ff;">GEST ART</h1>
    <p class="card-text"><legend><i>le gestionnaire d'article scientifique par excellence</i></legend></p>
    
  </div>
</div>