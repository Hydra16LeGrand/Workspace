<?php

	$db = new PDO('mysql:host=localhost;dbname=DevLogiciel','root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
	$row = $db->query("SELECT * FROM Utilisateur");
	$mavar = false;
	while ($reponse = $row->fetch()) {
		if ($reponse['id_utilisateur'] == $_POST['username'] AND $reponse['mdp_utilisateur'] == $_POST['pass']) {
			$mavar = true;
		}
	}

	$row->closeCursor();
	if ($mavar) {
		header('Location:bienvenue.php');
	}else{
		?>
			<h1> Mot de pass incorrect </h1>
		<?php
		header('Location:./../index.php');
	}
