<!-- Les liens bootstrap -->
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap-grid.min.css">
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap-grid.css">
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap-reboot-min.css">
<link rel="stylesheet" type="text/css" href="../Statics/bootstrap-4.4.1-dist/css/bootstrap-reboot.css">
<script type="text/javascript" src="bootstrap-4.1.1-dist/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap-4.1.1-dist/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap-4.1.1-dist/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="bootstrap-4.1.1-dist/bootstrap.bundle.js"></script>