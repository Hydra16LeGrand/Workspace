-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Ven 17 Janvier 2020 à 23:06
-- Version du serveur :  5.7.28-0ubuntu0.19.04.2
-- Version de PHP :  7.2.24-0ubuntu0.19.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `DevLogiciel`
--

-- --------------------------------------------------------

--
-- Structure de la table `Article`
--

CREATE TABLE `Article` (
  `id_article` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `noms_prenoms_auteurs` text NOT NULL,
  `resume` text NOT NULL,
  `statu` tinyint(1) NOT NULL,
  `nombre_evaluation` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Article`
--

INSERT INTO `Article` (`id_article`, `titre`, `noms_prenoms_auteurs`, `resume`, `statu`, `nombre_evaluation`) VALUES
(1, 'Article 1', 'Baradji Amara,\r\nCoulibaly Chonselgama,\r\nBoka Arthur', 'Le resume de cet article', 1, 0),
(2, 'Article2', 'Baradji AMara', 'Le resume de cet article', 0, 0),
(3, 'Article 3', 'Coulibaly Chonselgama', 'Le resume de cet article', 0, 0),
(4, 'Article 4', 'Boka guy roland', 'Le resume de cet article', 1, 0),
(5, 'Article 5', 'Boka guy roland', 'Le resume de cet article', 1, 0),
(6, 'Article 6', 'Coulibaly Chonselgama', 'Le resume de cet article', 1, 0),
(7, 'Article 7', 'Baradji Amara', 'Le resume de cet article', 1, 0),
(8, 'Article 8', 'Baradji Amara', 'Le resume de cet article', 1, 0),
(9, 'Article 9', 'Baradji Amara', 'Le resume de cet article', 1, 0),
(10, 'Article 10', 'Baradji Amara', 'Le resume de cet article', 2, 2),
(11, 'Article 11', 'Baradji Amara', 'Le resume de cet article', 2, 2),
(12, 'Article 12', 'Baradji Amara', 'Le resume de cet article', 2, 2),
(13, 'Article 13', 'Baradji Amara', 'Le resume de cet article', 2, 2),
(14, 'Article 14', 'Baradji Amara', 'Le resume de cet article', 1, 0),
(15, 'Article 15', 'Baradji Amara', 'Le resume de cet article', 1, 1),
(16, 'ArticleChai Pas', 'Baradji Amara', 'Le resume de cet article', 2, 2);

-- --------------------------------------------------------

--
-- Structure de la table `Evaluation`
--

CREATE TABLE `Evaluation` (
  `id_evaluation` int(11) NOT NULL,
  `nom_evaluateur` varchar(255) NOT NULL,
  `note_evaluation` int(11) NOT NULL,
  `mess_president` text NOT NULL,
  `commentaire` text NOT NULL,
  `id_article` int(11) NOT NULL,
  `titre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Evaluation`
--

INSERT INTO `Evaluation` (`id_evaluation`, `nom_evaluateur`, `note_evaluation`, `mess_president`, `commentaire`, `id_article`, `titre`) VALUES
(1, 'PrÃ©sident du comitÃ©', 4, 'mÃ©ssage 1', 'Commentaire 1', 10, 'Article 10'),
(2, 'PrÃ©sident du comitÃ©', 3, 'mÃ©ssage 2', 'Commentaire 2', 10, 'Article 10'),
(3, 'PrÃ©sident du comitÃ©', 4, 'mÃ©ssage 3', 'Commentaire 3', 10, 'Article 10'),
(4, 'PrÃ©sident du comitÃ©', 2, 'mÃ©ssage 1', 'commentaire 1', 11, 'Article 11'),
(5, 'PrÃ©sident du comitÃ©', 1, 'mÃ©ssage 2', 'Commentaire 2', 11, 'Article'),
(6, 'PrÃ©sident du comitÃ©', 2, 'message 3', 'Commentaire 3', 11, 'Article 11'),
(7, 'PrÃ©sident du comitÃ©', 4, 'message 1', 'Commentaire 1', 12, 'Article 12'),
(8, 'PrÃ©sident du comitÃ©', 1, 'message 2', 'Commentaire 2', 12, 'Article 12'),
(9, 'PrÃ©sident du comitÃ©', 2, 'message 3', 'Commentaire 3', 12, 'Article'),
(10, 'PrÃ©sident du comitÃ©', 3, 'message1', 'Commentaire 1', 13, 'Article 13'),
(11, 'PrÃ©sident du comitÃ©', 2, 'message 2', 'Commentaire 2', 13, 'Article 13'),
(12, 'PrÃ©sident du comitÃ©', 3, 'message 3', 'Commentaire 3', 13, 'Article 13'),
(13, 'PrÃ©sident du comitÃ©', 3, 'message 3', 'Commentaire 3', 13, 'Article 13'),
(14, 'PrÃ©sident du comitÃ©', 1, 'Message10', 'Commentaire10', 16, 'ArticleChai'),
(15, 'PrÃ©siden', 3, 'mÃ©ssage2', 'commentaire2', 16, 'ArticleChai'),
(16, 'PrÃ©sident du comitÃ©', 4, 'mÃ©ssage3', 'commentaire3', 16, 'ArticleChai'),
(17, 'PrÃ©sident du comitÃ©', 4, 'mÃ©ssage1', 'commentaire1', 15, 'Article 15');

-- --------------------------------------------------------

--
-- Structure de la table `Rapport`
--

CREATE TABLE `Rapport` (
  `id_rapport` int(11) NOT NULL,
  `titre` text NOT NULL,
  `decision` varchar(15) NOT NULL,
  `note_evaluation` int(11) NOT NULL,
  `id_article` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `Utilisateur`
--

CREATE TABLE `Utilisateur` (
  `id_utilisateur` varchar(35) NOT NULL,
  `mdp_utilisateur` varchar(35) NOT NULL COMMENT 'Le mot de passe de l''utilisateur'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `Utilisateur`
--

INSERT INTO `Utilisateur` (`id_utilisateur`, `mdp_utilisateur`) VALUES
('President', 'president1234');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Article`
--
ALTER TABLE `Article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `Evaluation`
--
ALTER TABLE `Evaluation`
  ADD PRIMARY KEY (`id_evaluation`);

--
-- Index pour la table `Rapport`
--
ALTER TABLE `Rapport`
  ADD PRIMARY KEY (`id_rapport`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Article`
--
ALTER TABLE `Article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `Evaluation`
--
ALTER TABLE `Evaluation`
  MODIFY `id_evaluation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `Rapport`
--
ALTER TABLE `Rapport`
  MODIFY `id_rapport` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
