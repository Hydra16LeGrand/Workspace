<?php
// Ce fichier va permettre l'affichage d'un formulaire proposé en pdf
	// Inclusion du fichier qui permet la réccupération des données à afficher.
	require('../Models/pdf_article_proposes.php');

	// Insertion du module fpdf qui va permettre de génerer le pdf.
	require('../PdfModuleFPDF/fpdf.php');


	foreach ($donnees as $donnee) {
		$titre = $donnee['titre'];
		$id_article = $donnee['id_article'];
		$noms_prenoms_auteurs=$donnee['noms_prenoms_auteurs'];
		$resume=$donnee['resume'];
	}

	// Instanciation de la classe FPDF
	$pdf = new FPDF();
	$pdf ->AddPage();
	$pdf->SetFont('Arial','B',13);

	$pdf->Text(15, 30 , utf8_decode('Article numéro '.$id_article));
	$pdf->Text(15,50,utf8_decode('Titre : '.$titre));
	$pdf->Text(15,70,utf8_decode('Noms des auteurs : '.$noms_prenoms_auteurs));

	
	$pdf->Text(15,100,utf8_decode('resumé article : '.$resume));

	$pdf->Output();

  ?>